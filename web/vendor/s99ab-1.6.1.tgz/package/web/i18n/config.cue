// i18n/config.cue
//
// S99Locale config for the layer's strings. The layer emits only the web target.
defaultLocale: "en"
locales: ["en", "pl"]
targets: ["web"]
roots: ["locales"]
output: "generated"
